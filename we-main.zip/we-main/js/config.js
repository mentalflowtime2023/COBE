export default {
  targets: document.querySelectorAll('.ani'),
  padding: '',
};