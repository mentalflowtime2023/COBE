
$('#BtnRight').click(function () {
});

$('#BtnLeft').click(function () {
});

